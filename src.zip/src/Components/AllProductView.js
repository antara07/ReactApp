import React, { useState, useEffect } from 'react'
import axios from 'axios'

function AllProductView() {
    const url = 'http://localhost:8080/product/list/';
    const [products, getProucts] = useState([]);
    useEffect(() => {
        getAllProducts();

    }, []);

    const getAllProducts = () => {
        axios.get(url).then(
            response => getProucts(response.data)
        ).catch(e =>
            console.error(e)
        );
    }
    return (
        <div>
            <h3>Product List</h3>
            <table>
                <tbody>
                    <tr><th>Order</th><th>Quantity</th></tr>
                    {products.map(p => {
                        return (
                            <tr>
                                <td key="{p.order}">{p.order}</td>
                                <td key="{p.quantity}">{p.quantity}</td>
                            </tr>
                        )

                    })}
                </tbody>
            </table>
        </div>
    )
}

export default AllProductView
