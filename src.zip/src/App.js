
import './App.css';
import AllProductView from './Components/AllProductView';

function App() {
  return (
    <AllProductView />
  );
}

export default App;
